Install Chrome Driver via brew
/usr/local/bin/chromedriver

or just point to the path in windows
